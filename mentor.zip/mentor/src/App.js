import React from 'react';
import { Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'primereact/resources/primereact.min.css';
import './App.css';
import Login from './components/Login';
import GlobalCourseSearch from './components/GlobalCourseSearch';
import AdminDashboard from './components/AdminDashboard';
import MentorDashboard from './components/MentorDashboard';
import StudentDashboard from './components/StudentDashboard';



function App() {
  return (
    <>
      <NavBar /> {/* Place NavBar outside of Routes */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />}/>
        <Route path="/search" element={<GlobalCourseSearch />}/>
        <Route path="/dashboard/admin" element={<AdminDashboard />}/>
        <Route path="/dashboard/mentor" element={<MentorDashboard />}/>
        <Route path="/dashboard/student" element={<StudentDashboard />}/>
        {/* Define more routes here if needed */}
      </Routes>
    </>
  );
}

export default App;
