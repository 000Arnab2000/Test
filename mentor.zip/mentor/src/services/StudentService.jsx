import axios from "axios";

function StudentService() {

    const enrollToCourse = async (courseId,mentorId, auth) => {
        const url = 'http://localhost:8087/StudentSelectCourseMentor/'+courseId+'/'+mentorId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.post(url,{}, { headers });
    };
    const getMyCourse = async (auth) => {
        const url = 'http://localhost:8087/StudentGetEnrolledCourse';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const getMyCertificates = async (auth) => {
        const url = 'http://localhost:8088/StudentGetReports';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const updateProfile = async (auth,body) => {
        const url = 'http://localhost:8087/UpdateStudentProfile';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.put(url,body, { headers });
    };

    return {
        enrollToCourse,getMyCourse,getMyCertificates,updateProfile
    };
}



export default StudentService;
