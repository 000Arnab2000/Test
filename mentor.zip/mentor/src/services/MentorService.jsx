import axios from "axios";

function MentorService() {

    const addMentor = async (courseId, auth) => {
        const url = 'http://localhost:8086/EnrollMentorToCourse/'+courseId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.post(url,{}, { headers });
    };

    

    const updateProfile = async (auth,body) => {
        const url = 'http://localhost:8086/UpdateMentorProfile';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.put(url,body, { headers });
    };


    const getEnrolledCourse = async (auth) => {
        const url = 'http://localhost:8086/MentorFindCourse';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const updateAvailibility = async (auth,body) => {
        const url = 'http://localhost:8085/MentorUpdateAvailability';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.put(url,body, { headers });
    };

    const getRequestedCourse = async (auth) => {
        const url = 'http://localhost:8085/MentorGetRequestedCourse';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const adminGetRequest = async (courseId,auth) => {
        const url = 'http://localhost:8085/AdminGetMentorRequest/'+courseId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const getMentorById = async (mentorId,auth) => {
        const url = 'http://localhost:8085/GetMentorById/'+mentorId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    const updateMentorRequest = async (status,requestId,auth) => {
        console.log("reaaa",requestId)
        const url = "http://localhost:8085/AdminUpdateMentorRequest/"+requestId+"/"+status;
        console.log("reaaa",auth)
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.put(url,{}, { headers });
    };

    return {
        addMentor,getEnrolledCourse,updateProfile,updateAvailibility,getRequestedCourse,adminGetRequest,getMentorById,updateMentorRequest
    };
}



export default MentorService;
