import axios from "axios";


function LoginService() {

    const userLogin = async (username, password) => {

        try {
            let url = 'http://localhost:8085/Authenticate';
            let body = {

                "username": username,
                "password": password

            }
            return await axios.post(
                url, body
            );
        }
        catch (e) {
            return "Invalid Credentials"
        }
    };

    const userSignup = async (body, type) => {
        let url = ""
        if (type === 'admin')
            url = 'http://localhost:8085/AdminSignup';
        else if (type === 'mentor')
            url = 'http://localhost:8085/MentorSignup';
        else
            url = 'http://localhost:8085/StudentSignup';

        const header = {
            "Authorization": "Bearer " + localStorage.getItem("jwtToken")
        }

        return await axios.post(
            url, body, header
        );
    };

    const viewProfile = async (auth) => {
        const url = 'http://localhost:8085/ViewProfile';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };


    return {
        userLogin, userSignup,viewProfile
    }
}
export default LoginService;