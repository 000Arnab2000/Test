import axios from "axios";

function CourseService() {

    const searchCourse = async (name) => {
        const url = 'http://localhost:8085/SearchCourse';
        const headers = { 
            'CourseName': name 
        };

        return await axios.get(url, { headers });
    };

    const getAllCourse = async (name) => {
        const url = 'http://localhost:8085/GetAllCourse';
        return await axios.get(url);
    };

    const addCourse = async (body, auth) => {
        const url = 'http://localhost:8085/AdminAddCourse';
        const headers = {
            "Authorization": "Bearer " + auth
        };
        console.log(auth)
        return await axios.post(url, body, { headers });
    };

    const addMentor = async (courseId, auth) => {
        const url = 'http://localhost:8085/EnrollMentorToCourse/'+courseId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.post(url,{}, { headers });
    };

    const getCourseMentor = async (courseId, auth) => {
        const url = 'http://localhost:8086/GetMentorsInCourse/'+courseId;
        const headers = {
            "Authorization": "Bearer " + auth
        };
        return await axios.get(url, { headers });
    };

    

    return {
        searchCourse,getAllCourse,addCourse,addMentor,getCourseMentor
    };
}



export default CourseService;
