// Navbar.jsx
import React, { useEffect, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import Button1 from 'react-bootstrap/Button';
import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import home1 from '../images/home1.png';
import home2 from '../images/home2.jpg'
import CourseService from '../services/CourseService';
import course1 from '../images/course1.jpg';
import course2 from '../images/course2.jpg';
import course3 from '../images/course3.avif';
import course4 from '../images/course4.avif';
import { Card, Form, Modal } from 'react-bootstrap';
import { Toast } from 'primereact/toast';
import MentorService from '../services/MentorService';
import LoginService from '../services/LoginService';

const MentorDashboard = () => {
    const toast = useRef(null);
    const [tab, setTab] = useState('course');
    const [courseData, setCourseData] = useState([]);
    const [myCourse, setMyCourse] = useState([]);
    const [isCourseUpdated, setIsCourseUpdated] = useState(false);
    const [onlyShowMyCourse, setOnlyShowMyCourse] = useState(false);
    const [myProfile, setMyProfile] = useState();
    const [courseStartDate, setCourseStartDate] = useState('');

    const [requestedCourse, setRequestedCourse] = useState([]);

    const [isEditProfile, setIsEditProfile] = useState(false);
    const [mySkills, setMySkills] = useState([]);
    const [courseDataCopy, setcourseDataCopy] = useState([]);
    const [globalSearch, setGlobalSearch] = useState(localStorage.getItem('globalSearchCourse'))


    useEffect(() => {

    }, isEditProfile)

    useEffect(() => {
        const interval = setInterval(() => {
            const newValue = localStorage.getItem('globalSearchCourse');
            if (newValue !== globalSearch) {
                setGlobalSearch(newValue);
                // Add your logic here that you want to trigger on localStorage change
                console.log('localStorage value changed:', newValue);
            }
        }, 1000); // Poll every second

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, [globalSearch]);

    useEffect(() => {
        const getData = async () => {
            const response = await CourseService().getAllCourse();
            if (localStorage.getItem('globalSearchCourse') !== null) {

                console.log('test useEffect', localStorage.getItem('globalSearchCourse'))
                setcourseDataCopy(response.data);
                const filteredCourses = response.data.filter(course =>
                    course.title.toLowerCase().includes(localStorage.getItem('globalSearchCourse').toLowerCase())
                );
                console.log("test", filteredCourses)
                setCourseData(filteredCourses);

            }
            else {
                console.log(response.data);
                setCourseData(response.data);
            }
        };

        const getEnrolledCourse = async () => {
            const response = await MentorService().getEnrolledCourse(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setMyCourse(response.data);
        };
        const getRequestedCourse = async () => {
            const response = await MentorService().getRequestedCourse(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setRequestedCourse(response.data);
        };
        const viewProfile = async () => {
            const response = await LoginService().viewProfile(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setMyProfile(response.data);
            setMySkills(response.data.skills)
        };
        getData();
        getEnrolledCourse();
        getRequestedCourse();
        viewProfile();
    }, [isCourseUpdated, globalSearch]);

    const showSccessToast = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Enrolement Request Sent`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const showSccessToast1 = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Profile Updated Successfully`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const getRandomInt = (min, max) => {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };

    const enrollAsMentor = async (course) => {
        console.log("date test", courseStartDate)
        const newDate = new Date(courseStartDate);
        console.log("date test2", course.duration)
        newDate.setDate(newDate.getDate() + course.duration); // Add 30 days
        console.log("date test2", newDate)
        const generatedEndDate = newDate.toISOString().split('T')[0]; // Format the date as YYYY-MM-DD
        let data = {
            "startDate": courseStartDate,
            "endDate": generatedEndDate,
            "status": "AVAILABLE"
        }
        const response1 = await MentorService().updateAvailibility(localStorage.getItem('jwtToken'), data);
        console.log(response1.data);
        const response = await CourseService().addMentor(course.id, localStorage.getItem('jwtToken'));
        console.log(response.data);
        setIsCourseUpdated(!isCourseUpdated);
        await showSccessToast();
    };

    const handleAddSkill = (e) => {
        e.preventDefault();
        console.log('skill test')
        let arr = mySkills
        arr.push('')
        setMySkills([...arr]); // Add a new empty skill field
    };

    const handleRemoveSkill = (index) => {
        const updatedSkills = mySkills.filter((_, i) => i !== index);
        setMySkills(updatedSkills); // Remove the skill at the specified index
    };

    const handleSkillChange = (index, value) => {
        const updatedSkills = mySkills.map((skill, i) => (i === index ? value : skill));
        setMySkills(updatedSkills); // Update skill value at the specified index
    };

    const updateProfile = async (e) => {
        e.preventDefault();
        let data = myProfile
        data.skills = mySkills;
        const response = await MentorService().updateProfile(localStorage.getItem('jwtToken'), data);
        console.log(response.data);
        setIsEditProfile(!isEditProfile);
        await showSccessToast1();

    };


    const imageMap = {
        1: course1,
        2: course2,
        3: course3,
        4: course4
    };

    return (
        <>
            <div>
                <div style={styles.sidebar}>
                    <Button
                        onClick={() => setTab('account')}
                        icon="pi pi-user"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                    <Button
                        onClick={() => setTab('course')}
                        icon="pi pi-objects-column"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                </div>
            </div>
            <div style={{ marginTop: '100px' }}>
                {tab === "course" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>

                        <Form style={{ marginTop: "20px", marginLeft: '100px' }}>
                            <Form.Check // prettier-ignore
                                type="switch"
                                id="custom-switch"
                                onChange={() => setOnlyShowMyCourse(!onlyShowMyCourse)}
                                label="Show My Course Only"
                            />
                        </Form>

                        {!onlyShowMyCourse ?
                            <div style={styles.cardContainer}>
                                {courseData.map((data) => {
                                    let imageNumber = getRandomInt(1, 4);
                                    let imageSrc = imageMap[imageNumber];
                                    let isEnrolled = false;
                                    let isRequested = false;
                                    if (myCourse.some(courseData => courseData.id === data.id))
                                        isEnrolled = true;
                                    if (requestedCourse.some(courseData => courseData.id === data.id))
                                        isRequested = true;
                                    return (
                                        <Card
                                            key={data.id}
                                            style={{
                                                position: 'relative',
                                                width: '500px',
                                                height: '400px',
                                                backgroundSize: 'cover',
                                                backgroundPosition: 'center',
                                                color: 'white',
                                                margin: '10px',
                                                backgroundImage: `url(${imageSrc})`,
                                            }}
                                        >
                                            <center><div style={styles.cardContent}>
                                                <h4>{data.title}</h4>
                                                <br />
                                                <h5>{data.description}</h5>
                                                <h4>Duration: {data.duration} days</h4>
                                                <br />
                                                <div style={{ display: 'flex' }}>
                                                    {!isEnrolled ?
                                                        <>
                                                            {!isRequested ?
                                                                <Form onSubmit={(e) => {
                                                                    e.preventDefault();
                                                                    enrollAsMentor(data)

                                                                }}>
                                                                    <Form.Group style={{ display: 'flex' }} className="mb-3" controlId="formBasicFullNameMentor">
                                                                        <Form.Label><h5>Course Start date:&nbsp;&nbsp;</h5></Form.Label>
                                                                        <Form.Control required onChange={(e) => setCourseStartDate(e.target.value)} style={{ width: "200px" }} type="date" placeholder="Enter Full Nam" />
                                                                    </Form.Group>
                                                                    <Button1
                                                                        type='submit'
                                                                        style={{ width: '200px' }}
                                                                        variant='dark'
                                                                    >
                                                                        Enroll As Mentor
                                                                    </Button1>
                                                                </Form>
                                                                :
                                                                <Button1
                                                                    type='submit'
                                                                    style={{ width: '200px' }}
                                                                    variant='dark'
                                                                    disabled
                                                                >
                                                                    Requested
                                                                </Button1>
                                                            }</>
                                                        :
                                                        <Button1
                                                            style={{ width: '200px' }}
                                                            variant='dark'
                                                            disabled
                                                            onClick={() => enrollAsMentor(data.id)}
                                                        >
                                                            Enrolled
                                                        </Button1>

                                                    }
                                                </div>
                                            </div>
                                            </center>
                                        </Card>
                                    );
                                })}
                            </div>
                            :
                            <div style={styles.cardContainer}>
                                {myCourse.map((data) => {
                                    let imageNumber = getRandomInt(1, 4);
                                    let imageSrc = imageMap[imageNumber];

                                    return (
                                        <Card
                                            key={data.id}
                                            style={{
                                                position: 'relative',
                                                width: '500px',
                                                height: '300px',
                                                backgroundSize: 'cover',
                                                backgroundPosition: 'center',
                                                color: 'white',
                                                margin: '10px',
                                                backgroundImage: `url(${imageSrc})`,
                                            }}
                                        >
                                            <center><div style={styles.cardContent}>
                                                <h4>{data.title}</h4>
                                                <br />
                                                <h5>{data.description}</h5>
                                                <h4>Duration: {data.duration} days</h4>
                                                <div style={{ display: 'flex' }}>
                                                    <Button1
                                                        style={{ width: '200px' }}
                                                        variant='dark'
                                                        disabled
                                                        onClick={() => enrollAsMentor(data.id)}
                                                    >
                                                        Enrolled
                                                    </Button1>
                                                </div>
                                            </div>
                                            </center>
                                        </Card>
                                    );
                                })}
                            </div>
                        }
                    </div>
                }
                {tab === "account" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>
                        {myProfile &&
                            <center>
                                <Card style={{ padding: '30px', boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)' }}>
                                    <div style={{ backgroundColor: '#F5EFB0', width: '100%', marginLeft: '-20px' }}>
                                        <center><h5>Your profile</h5></center>
                                    </div>
                                    <div style={{ marginTop: '30px' }}>
                                        <Form onSubmit={(e) => updateProfile(e)}>
                                            <div style={{ display: 'flex' }}>
                                                <Form.Group className="mb-3" controlId="formBasicFullNameMentorUpdate" style={{ display: 'flex' }} >
                                                    <Form.Label style={{ marginTop: '8px' }}><b>Name:&nbsp;&nbsp;</b></Form.Label>
                                                    <Form.Control required onChange={(e) => {
                                                        let data = myProfile;
                                                        data.fullName = e.target.value;
                                                        console.log(data);
                                                        setMyProfile(data);
                                                    }} defaultValue={myProfile.fullName} style={{ width: "500px" }} type="text" placeholder="Enter Full Name" />
                                                </Form.Group>
                                                <Form.Group className="mb-3" controlId="formBasicMobNoMentorUpdate" style={{ display: 'flex', marginLeft: '50px' }} >
                                                    <Form.Label style={{ marginTop: '8px' }}><b>Mobile Number:&nbsp;&nbsp;</b></Form.Label>
                                                    <Form.Control required onChange={(e) => {
                                                        let data = myProfile;
                                                        data.mobNo = e.target.value;
                                                        console.log(data);
                                                        setMyProfile(data);
                                                    }} defaultValue={myProfile.mobNo} style={{ width: "320px" }} type="number" placeholder="Enter Full Name" />
                                                </Form.Group>
                                            </div>
                                            <div style={{ display: 'flex' }}>
                                                <Form.Group className="mb-3" controlId="formBasicSkillsMentorUpdate" style={{ display: 'flex' }} >
                                                    <div style={{ display: 'block' }}>
                                                        <Form.Label style={{ marginTop: '8px' }}><b>Skills:&nbsp;&nbsp;</b></Form.Label>
                                                        <br />
                                                        <Button onClick={(e) => handleAddSkill(e)} text icon='pi pi-plus-circle' />
                                                    </div>
                                                    <div style={{ display: 'block' }}>
                                                        {mySkills.map((skill, index) => (
                                                            <div style={{ display: 'flex' }} >
                                                                <Form.Control required onChange={(e) => handleSkillChange(index, e.target.value)} defaultValue={skill !== '' ? skill : ''} style={{ width: "500px", marginTop: '10px' }} type="text" placeholder="Enter New Skill" />
                                                                <Button onClick={() => handleRemoveSkill(index)} text icon='pi pi-trash' />
                                                            </div>
                                                        ))}
                                                    </div>
                                                </Form.Group>
                                                <Form.Group className="mb-3" controlId="formBasicExperienceMentorUpdate" style={{ display: 'flex', marginLeft: '50px' }} >
                                                    <Form.Label style={{ marginTop: '15px' }}><b>Experience(years):&nbsp;&nbsp;</b></Form.Label>
                                                    <Form.Control required onChange={(e) => {
                                                        let data = myProfile;
                                                        data.experience = e.target.value;
                                                        console.log(data);
                                                        setMyProfile(data);
                                                    }} defaultValue={myProfile.experience} style={{ width: "280px", height: '40px', marginTop: '10px' }} type="number" placeholder="Enter Full Name" />
                                                </Form.Group>
                                            </div>
                                            <Button type='submit' icon='pi pi-pen-to-square' severity="secondary" outlined style={{ borderRadius: '5px' }}>&nbsp;Update Profile</Button>

                                        </Form>
                                        <br />

                                    </div>
                                </Card>
                            </center>
                        }
                    </div>
                }
                <div className="toast-bottom">
                    <Toast ref={toast} position="bottom-right" />
                </div>
            </div>
        </>
    );
};

const styles = {
    sidebar: {
        width: '50px',
        height: '115vh',
        position: 'fixed',
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        boxShadow: '2px 0 4px rgba(0, 0, 0, 0.5)',
        padding: '10px 0',
        marginTop: '-100px',
        zIndex: '1'
    },
    sidebarButton: {
        fontSize: '1.5rem',
        marginBottom: '10px', // Add spacing between buttons
    },
    cardContainer: {
        display: 'flex',
        flexWrap: 'wrap', // Allows wrapping of cards
        justifyContent: 'center',
        marginTop: '20px',
    },
    card: {
        position: 'relative',
        width: '500px',
        height: '300px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: 'white',
        margin: '10px',
        backgroundImage: `url(${course1})`, // You can dynamically set this in the map method
    },
    cardContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
        background: 'rgba(0, 0, 0, 0.4)', // Optional: to add a dark overlay
    },
};

export default MentorDashboard;
