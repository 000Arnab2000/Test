// Navbar.jsx
import React, { useEffect, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import Button1 from 'react-bootstrap/Button';
import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import home1 from '../images/home1.png';
import home2 from '../images/home2.jpg'
import CourseService from '../services/CourseService';
import course1 from '../images/course1.jpg';
import course2 from '../images/course2.jpg';
import course3 from '../images/course3.avif';
import course4 from '../images/course4.avif';
import { Card, Form, Modal, ModalBody, Table } from 'react-bootstrap';
import { Toast } from 'primereact/toast';
import MentorService from '../services/MentorService';

const AdminDashboard = () => {
    const toast = useRef(null);
    const [tab, setTab] = useState('course');
    const [courseData, setCourseData] = useState([]);
    const [addModalShow, setAddModalShow] = useState(false);
    const [isCourseUpdated, setIsCourseUpdated] = useState(false);
    const [courseDataCopy, setcourseDataCopy] = useState([]);
    const [globalSearch, setGlobalSearch] = useState(localStorage.getItem('globalSearchCourse'))

    const [showRequestModal, setShowRequestModal] = useState(false);
    const [selectedCourse, setSelectedCourse] = useState();
    const [mentorsInSelectedCourse, setMentorsInSelectedCourse] = useState([]);
    const [mentorRequests, setMentorRequests] = useState([]);

    useEffect(() => {
        const interval = setInterval(() => {
            const newValue = localStorage.getItem('globalSearchCourse');
            if (newValue !== globalSearch) {
                setGlobalSearch(newValue);
                // Add your logic here that you want to trigger on localStorage change
                console.log('localStorage value changed:', newValue);
            }
        }, 1000); // Poll every second

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, [globalSearch]);

    useEffect(() => {
        const getData = async () => {
            const response = await CourseService().getAllCourse();
            if (localStorage.getItem('globalSearchCourse') !== null) {

                console.log('test useEffect', localStorage.getItem('globalSearchCourse'))
                setcourseDataCopy(response.data);
                const filteredCourses = response.data.filter(course =>
                    course.title.toLowerCase().includes(localStorage.getItem('globalSearchCourse').toLowerCase())
                );
                console.log("test", filteredCourses)
                setCourseData(filteredCourses);

            }
            else {
                console.log(response.data);
                setCourseData(response.data);
            }
        };

        getData();
    }, [isCourseUpdated, globalSearch]);

    const showSccessToast = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Course Added Successfully`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const showSccessToast1 = (data) => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: data ? 'Request Accepted' : 'Request Rejected',
                
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const getRandomInt = (min, max) => {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };

    const handleSelectedCourse = async (data) => {

        const responseRequest = await MentorService().adminGetRequest(data.id, localStorage.getItem('jwtToken'));
        setMentorRequests(responseRequest.data);

        let mentorDataList = [];
        if (responseRequest.data.length > 0) {
            for (let i = 0; i < responseRequest?.data?.length; i++) {
                const response = await MentorService().getMentorById(responseRequest.data[i]?.mentorId, localStorage.getItem('jwtToken'));
                mentorDataList.push(response.data);
            }
        }
        setMentorsInSelectedCourse(mentorDataList);
        setShowRequestModal(true)
    };

    const handleCourseAdd = async (e) => {
        e.preventDefault();
        let title = e.target.formBasicCourseTitleAdd.value;
        let description = e.target.formBasicCourseDescriptionAdd.value;
        let duration = e.target.formBasicCourseDurationAdd.value;

        let body = {
            "title": title,
            "description": description,
            "duration": duration,
            "mentors": [],
            "students": []
        }

        const response = await CourseService().addCourse(body, localStorage.getItem('jwtToken'));
        console.log(response.data);
        setIsCourseUpdated(!isCourseUpdated);
        await showSccessToast();

    };

    const imageMap = {
        1: course1,
        2: course2,
        3: course3,
        4: course4
    };

    return (
        <>
            <div>
                <div style={styles.sidebar}>

                    <Button
                        onClick={() => setTab('course')}
                        icon="pi pi-objects-column"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                </div>
            </div>
            <div style={{ marginTop: '100px' }}>
                {tab === "course" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>
                        <div style={{ marginLeft: '70px' }}>
                            <Button1 onClick={() => setAddModalShow(true)} variant='outline-dark'>Add New Course</Button1>
                        </div>
                        <Modal style={{ display: 'block' }} show={addModalShow} onHide={() => setAddModalShow(false)}>
                            <Modal.Header closeButton>
                                <Modal.Title>Add Course</Modal.Title>
                            </Modal.Header>

                            <Modal.Body>
                                <center>
                                    <Form onSubmit={handleCourseAdd} style={styles.logo}>
                                        <Form.Group className="mb-3" controlId="formBasicCourseTitleAdd">
                                            <Form.Control
                                                required
                                                style={{ width: "470px", marginTop: '10px', borderRadius: '10px' }}
                                                type="text"
                                                placeholder="Enter title"
                                            />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicCourseDescriptionAdd">
                                            <Form.Control required style={{ width: "470px", marginTop: '10px', borderRadius: '10px' }}
                                                as="textarea" rows={3}
                                                placeholder="Enter Description" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicCourseDurationAdd">
                                            <Form.Control
                                                style={{ width: "470px", marginTop: '10px', borderRadius: '10px' }}
                                                type="number"
                                                required
                                                placeholder="Enter Duration in Days"
                                            />
                                        </Form.Group>
                                        <Button1
                                            style={{ width: '300px' }}
                                            type="submit"
                                            variant='outline-dark'
                                        >Add</Button1>
                                    </Form>
                                </center>
                            </Modal.Body>

                        </Modal>
                        <div style={styles.cardContainer}>
                            {courseData.map((data) => {
                                let imageNumber = getRandomInt(1, 4);
                                let imageSrc = imageMap[imageNumber];

                                return (
                                    <Card
                                        onClick={() => {
                                            setSelectedCourse(data)
                                            handleSelectedCourse(data);
                                        }}
                                        key={data.id}
                                        style={{
                                            position: 'relative',
                                            width: '500px',
                                            height: '300px',
                                            backgroundSize: 'cover',
                                            backgroundPosition: 'center',
                                            color: 'white',
                                            margin: '10px',
                                            backgroundImage: `url(${imageSrc})`,
                                        }}
                                    >
                                        <center><div style={styles.cardContent}>
                                            <h4>{data.title}</h4>
                                            <br />
                                            <h5>{data.description}</h5>
                                            <h4>Duration: {data.duration} days</h4>
                                            {/* <div style={{ display: 'flex' }}>
                                                <Button1
                                                    style={{ width: '200px' }}
                                                    variant='dark'>
                                                    Edit details
                                                </Button1>
                                                <Button
                                                    style={{ marginLeft: '30px', backgroundColor: 'red', borderRadius: '5px' }}
                                                    icon='pi pi-trash'>
                                                </Button>
                                            </div> */}
                                        </div>
                                        </center>
                                    </Card>
                                );
                            })}
                        </div>
                        <Modal style={{ display: 'block' }} show={showRequestModal} onHide={() => setShowRequestModal(false)}>
                            <Modal.Header closeButton>
                            </Modal.Header>

                            <Modal.Body>
                                {mentorsInSelectedCourse.length > 0 ?
                                    <Table striped bordered hover responsive>
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Experience</th>
                                                <th>Skills</th>
                                                <th>Mobile Number</th>
                                                <th>Actions</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                            {mentorsInSelectedCourse.map((mentor, index) => {
                                                let matchingRequest={};

                                                let hasRequested = mentorRequests.some(request => request.mentorId === mentor.id);
                                                if(hasRequested)
                                                    matchingRequest = mentorRequests.find(request => request.mentorId === mentor.id);
                                                console.log("reqqqq",matchingRequest.id)
                                                return (
                                                    <tr key={index}>
                                                        <td>{mentor.fullName}</td>
                                                        <td>{mentor.experience} years</td>
                                                        <td>{mentor.skills.join(', ')}</td>
                                                        <td>{mentor.mobNo}</td>
                                                        {hasRequested &&
                                                            <td style={{ display: 'flex', minHeight: '70px' }}>
                                                                <Button onClick={async ()=>{
                                                                    const responseFinal = await MentorService().updateMentorRequest("ACCEPTED",Number(matchingRequest?.id), localStorage.getItem('jwtToken'));
                                                                    
                                                                    if(responseFinal.data === "Successfull"){
                                                                        console.log(responseFinal.data)
                                                                        await  showSccessToast1(true);
                                                                    }
                                                                      
                                                                }} text icon='pi pi-check' />
                                                                <Button onClick={async ()=>{
                                                                    const responseFinal = await MentorService().updateMentorRequest("REJECTED",Number(matchingRequest?.id), localStorage.getItem('jwtToken'));
                                                                    if(responseFinal.data === "Successfull"){
                                                                        console.log(responseFinal.data)
                                                                        await  showSccessToast1(false);
                                                                        setShowRequestModal(false);
                                                                        setIsCourseUpdated(!isCourseUpdated);
                                                                    }
                                                                      }}
                                                                     text style={{ marginLeft: '10px' }} icon='pi pi-times' />
                                                            </td>
                                                        }
                                                    </tr>

                                                )
                                            })}
                                        </tbody>
                                    </Table>
                                    :
                                    <h5>No Mentors Present !</h5>
                                }
                            </Modal.Body>
                        </Modal>
                    </div>
                }
                <div className="toast-bottom">
                    <Toast ref={toast} position="bottom-right" />
                </div>
            </div >
        </>
    );
};

const styles = {
    sidebar: {
        width: '50px',
        height: '115vh',
        position: 'fixed',
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        boxShadow: '2px 0 4px rgba(0, 0, 0, 0.5)',
        padding: '10px 0',
        marginTop: '-100px',
        zIndex: '1'
    },
    sidebarButton: {
        fontSize: '1.5rem',
        marginBottom: '10px', // Add spacing between buttons
    },
    cardContainer: {
        display: 'flex',
        flexWrap: 'wrap', // Allows wrapping of cards
        justifyContent: 'center',
        marginTop: '20px',
    },
    card: {
        position: 'relative',
        width: '500px',
        height: '300px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: 'white',
        margin: '10px',
        backgroundImage: `url(${course1})`, // You can dynamically set this in the map method
    },
    cardContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
        background: 'rgba(0, 0, 0, 0.4)', // Optional: to add a dark overlay
    },
};

export default AdminDashboard;
