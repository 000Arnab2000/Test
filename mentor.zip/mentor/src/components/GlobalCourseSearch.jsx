import React, { useEffect, useState } from 'react';
import { Card } from 'react-bootstrap';
import CourseService from '../services/CourseService';

import course1 from '../images/course1.jpg';
import course2 from '../images/course2.jpg';
import course3 from '../images/course3.avif';
import course4 from '../images/course4.avif';

const GlobalCourseSearch = () => {
    const [courseData, setCourseData] = useState([]);
    const [courseDataCopy, setcourseDataCopy] = useState([]);
    const [globalSearch, setGlobalSearch] = useState(localStorage.getItem('globalSearchCourse'))


    useEffect(() => {
        const interval = setInterval(() => {
            const newValue = localStorage.getItem('globalSearchCourse');
            if (newValue !== globalSearch) {
                setGlobalSearch(newValue);
                // Add your logic here that you want to trigger on localStorage change
                console.log('localStorage value changed:', newValue);
            }
        }, 1000); // Poll every second

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, [globalSearch]);

    useEffect(() => {
        const getData = async () => {
            const response = await CourseService().getAllCourse();
            if (localStorage.getItem('globalSearchCourse') !== null) {

                console.log('test useEffect', localStorage.getItem('globalSearchCourse'))
                setcourseDataCopy(response.data);
                const filteredCourses = response.data.filter(course =>
                    course.title.toLowerCase().includes(localStorage.getItem('globalSearchCourse').toLowerCase())
                );
                console.log("test", filteredCourses)
                setCourseData(filteredCourses);

            }
            else {
                console.log(response.data);
                setCourseData(response.data);
            }
        };

        getData();
    }, [localStorage.getItem('globalSearchCourse')]);

    const getRandomInt = (min, max) => {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };

    const imageMap = {
        1: course1,
        2: course2,
        3: course3,
        4: course4
    };

    return (
        <>
            <center>
                <div style={{ backgroundColor: '#F5EFB0', width: '90%', marginLeft: '0px', marginTop: '100px' }}>
                    <center><h5>Courses</h5></center>
                </div>
                <h5>* Please log in to book your course and view additional details!</h5>
            </center>
            <div style={styles.cardContainer}>             
                {courseData.map((data) => {
                    let imageNumber = getRandomInt(1, 4);
                    let imageSrc = imageMap[imageNumber];

                    return (
                        <Card

                            key={data.id}
                            style={{
                                position: 'relative',
                                width: '500px',
                                height: '300px',
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                                color: 'white',
                                margin: '10px',
                                backgroundImage: `url(${imageSrc})`,
                            }}
                        >
                            <center><div style={styles.cardContent}>
                                <h4>{data.title}</h4>
                                <br />
                                <h5>{data.description}</h5>
                                <h4>Duration: {data.duration} days</h4>


                            </div>
                            </center>
                        </Card>
                    );
                })}
            </div>
        </>
    );
};

const styles = {
    sidebar: {
        width: '50px',
        height: '115vh',
        position: 'fixed',
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        boxShadow: '2px 0 4px rgba(0, 0, 0, 0.5)',
        padding: '10px 0',
        marginTop: '-100px',
        zIndex: '1'
    },
    sidebarButton: {
        fontSize: '1.5rem',
        marginBottom: '10px', // Add spacing between buttons
    },
    cardContainer: {
        display: 'flex',
        flexWrap: 'wrap', // Allows wrapping of cards
        justifyContent: 'center',
        marginTop: '20px',
    },
    card: {
        position: 'relative',
        width: '500px',
        height: '300px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: 'white',
        margin: '10px',
        backgroundImage: `url(${course1})`, // You can dynamically set this in the map method
    },
    cardContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '20px',
        background: 'rgba(0, 0, 0, 0.4)', // Optional: to add a dark overlay
    },
};
export default GlobalCourseSearch;
