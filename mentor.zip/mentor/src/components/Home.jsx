// Navbar.jsx
import React from 'react';
import { Button } from 'primereact/button';
import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import home1 from '../images/home1.png';
import home2 from '../images/home2.jpg'

const Home = () => {
    return (
        <>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginTop: "18vh" }}>
                <img height='550' src={home1} alt="" />
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginTop: "2vh" }}>
                <img height='400' src={home2} alt="" />
            </div>

        </>
    );
};


export default Home;
