import React, { useRef, useState } from 'react';

import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import { Card, Col, Row } from 'react-bootstrap';
import Button1 from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Button } from 'primereact/button';
import loginImg from '.././images/login.jpg';
import { useNavigate } from 'react-router-dom';
import LoginService from '../services/LoginService';
import { Toast } from 'primereact/toast';

const Login = () => {
    const toast = useRef(null);
    const navigate = useNavigate();
    const [type, setType] = useState('student');
    const [hasAccount, setHasAccount] = useState(false);
    const [skills, setSkills] = useState(['']);
    const [err, setErr] = useState('');

    const showSccessToast = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Logged in Successfully`,
                    life: 1000
                });
                // Resolve the promise after the toast is displayed for 2 seconds
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

   

    const showSccessToast1 = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Account created Successfully`,
                    life: 2000
                });
                // Resolve the promise after the toast is displayed for 2 seconds
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const handleSkillChange = (index, value) => {
        const newSkills = [...skills];
        newSkills[index] = value;
        setSkills(newSkills);
    };

    const addSkillField = () => {
        setSkills([...skills, '']);
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        const response = await LoginService().userLogin(e.target.formBasicEmailLogin.value, e.target.formBasicPasswordLogin.value);
        if (response?.data) {
            const currentTime = new Date().getTime(); // Get the current time in milliseconds (since Jan 1, 1970)
            localStorage.setItem("tokenIssueTime", currentTime)
            console.log(response.data.jwtToken)
            localStorage.setItem('jwtToken', response.data.jwtToken);
            localStorage.setItem('type', type);
            await showSccessToast(); // Wait for the toast to finish showing
            navigate('/'); // Navigate after the toast is shown
        }
        else {
            setErr('* Credentials Invalid!')
        }
    };

    const handleSignup = async (e) => {
        e.preventDefault();
        let body = {};
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>])[a-zA-Z\d!@#$%^&*(),.?":{}|<>]{8,}$/;

        if (type === 'admin') {
            if (e.target.formBasicPasswordAdmin?.value !== e.target.formBasicConfirmPasswordAdmin.value)
                setErr('* Password and confirm password must match !')
            else if(e.target.formBasicMasterPasswordAdmin.value !== 'rootAdmin')
                setErr('* Invalid Master Password !')
            else {
                if (passwordRegex.test(e.target.formBasicPasswordAdmin.value)) {
                    body = {

                        "email": e.target.formBasicEmailAdmin.value,
                        "password": e.target.formBasicPasswordAdmin.value,
                        "masterPassword": e.target.formBasicMasterPasswordAdmin.value

                    }
                }
                else {
                    setErr('* Password must be at least 8 characters long, contain one uppercase letter, one lowercase letter, and one special character')
                }
            }
        }
        if (type === 'mentor') {
            if (e.target.formBasicPasswordMentor.value !== e.target.formBasicConfirmPasswordMentor.value)
                setErr('* Password and confirm password must match !')
            else {
                if (passwordRegex.test(e.target.formBasicPasswordMentor.value)) {
                    body = {

                        "email": e.target.formBasicEmailMentor.value,
                        "password": e.target.formBasicPasswordMentor.value,
                        "fullName": e.target.formBasicFullNameMentor.value,
                        "experience": e.target.formBasicExperienceMentor.value,
                        "skills": skills,
                        "mobNo": e.target.formBasicMobileNumberMentor.value,
                        "availibility": {
                        }

                    }
                }
                else {
                    setErr('* Password must be at least 8 characters long, contain one uppercase letter, one lowercase letter, and one special character')
                }
            }
        }
        if (type === 'student') {
            if (e.target.formBasicPasswordStudent.value !== e.target.formBasicConfirmPasswordStudent.value)
                setErr('* Password and confirm password must match !')
            else {
                if (passwordRegex.test(e.target.formBasicPasswordStudent.value)) {
                    body = {

                        "email": e.target.formBasicEmailStudent.value,
                        "password": e.target.formBasicPasswordStudent.value,
                        "fullName": e.target.formBasicNameStudent.value,
                        "age": e.target.formBasicAgeStudent.value,
                        "mobNo": e.target.formBasicMobNoStudent.value

                    }
                }
                else {
                    setErr('* Password must be at least 8 characters long, contain one uppercase letter, one lowercase letter, and one special character')
                }
            }
        }
        if (body?.email) {
            const response = await LoginService().userSignup(body, type);
            console.log(response.data)
            await showSccessToast1(); // Wait for the toast to finish showing
            const response1 = await LoginService().userLogin(body.email, body.password);
            console.log(response1.data.jwtToken)
            localStorage.setItem('jwtToken', response1.data.jwtToken);
            localStorage.setItem('type', type);
            await showSccessToast(); // Wait for the toast to finish showing
            navigate('/'); // Navigate after the toast is shown
        }


    };

    const renderMentorForm = () => (
        <div>
            <center><h4 className="">Create a new Mentor Account</h4></center>
            <center><h5>Enter the information below</h5></center>
            <br />
            <center>
                <Form onSubmit={handleSignup}>
                    <Form.Group className="mb-3" controlId="formBasicFullNameMentor">
                        <Form.Control required style={{ width: "500px" }} type="text" placeholder="Enter Full Name" />
                    </Form.Group>
                    <div style={{ display: 'flex' }}>
                        <Form.Group className="mb-3" controlId="formBasicExperienceMentor">
                            <Form.Control required style={{ width: "190px" }} type="number" placeholder="Years of Experience" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicMobileNumberMentor">
                            <Form.Control required style={{ width: "280px", marginLeft: "30px" }} type="number" placeholder="Enter Mobile Number" />
                        </Form.Group>
                    </div>

                    {skills.map((skill, index) => (
                        <Form.Group className="mb-3" key={index} controlId={`formBasicSkill${index}`}>
                            <Form.Control
                                style={{ width: "500px" }}
                                type="text"
                                required
                                placeholder="Enter Skill"
                                value={skill}
                                onChange={(e) => handleSkillChange(index, e.target.value)}
                            />
                        </Form.Group>
                    ))}
                    <Button1 style={{ width: "200px" }} variant="outline-dark" onClick={addSkillField}>
                        Add Skill
                    </Button1>

                    <Form.Group className="mb-3" controlId="formBasicEmailMentor">
                        <Form.Control required style={{ width: "500px", marginTop: "10px" }} type="email" placeholder="Enter email" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicPasswordMentor">
                        <Form.Control required style={{ width: "500px" }} type="password" placeholder="Enter Password" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicConfirmPasswordMentor">
                        <Form.Control required style={{ width: "500px" }} type="password" placeholder="Confirm Password" />
                    </Form.Group>
                    {err !== '' &&
                        <span style={{ color: "red" }}>{err}</span>}
                    <br />
                    <Button1 style={{ width: "200px" }} variant="outline-dark" type="submit">
                        Sign Up
                    </Button1>
                    <center><Button1 onClick={() => setHasAccount(true)} style={{ width: "500px" }} variant="link" type="submit">
                        Already have an Account?
                    </Button1></center>
                </Form>
            </center>
        </div>
    );

    const renderAdminForm = () => (
        <>
            <center><h4 className="">Create a new Admin Account</h4></center>
            <center><h5>Enter the information below</h5></center>
            <br />
            <center>
                <Form onSubmit={handleSignup}>
                    <Form.Group className="mb-3" controlId="formBasicEmailAdmin">
                        <Form.Control required style={{ width: "500px" }} type="email" placeholder="Enter Email" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicMasterPasswordAdmin">
                        <Form.Control required style={{ width: "500px" }} type="password" placeholder="Enter Master Password" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicPasswordAdmin">
                        <Form.Control required style={{ width: "500px" }} type="password" placeholder="Enter Password" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicConfirmPasswordAdmin">
                        <Form.Control required style={{ width: "500px" }} type="password" placeholder="Confirm Password" />
                    </Form.Group>
                    {err !== '' &&
                        <span style={{ color: "red" }}>{err}</span>}
                    <br />

                    <Button1 style={{ width: "200px" }} variant="outline-dark" type="submit">
                        Sign Up
                    </Button1>
                    <center><Button1 onClick={() => setHasAccount(true)} style={{ width: "500px" }} variant="link" type="submit">
                        Already have an Account?
                    </Button1></center>
                </Form>
            </center>
        </>
    );

    return (
        <>
            <div>
                <Row>
                    <div>
                        <div style={styles.sidebar}>
                            <Button
                                onClick={() => setType('admin')}
                                icon="pi pi-user"
                                className="p-button-text"
                                style={{ ...styles.sidebarButton, fontSize: '20px' }}
                            >
                                &nbsp;Admin
                            </Button>
                            <br />
                            <Button
                                onClick={() => setType('mentor')}
                                icon="pi pi-user"
                                className="p-button-text"
                                style={{ ...styles.sidebarButton, fontSize: '20px' }}
                            >
                                &nbsp;Mentor
                            </Button>
                            <br />
                            <Button
                                onClick={() => setType('student')}
                                icon="pi pi-users"
                                className="p-button-text"
                                style={{ ...styles.sidebarButton, fontSize: '20px' }}
                            >
                                &nbsp;Student
                            </Button>
                            <br />
                            
                        </div>
                    </div>
                    <Col>
                        <img style={{ marginLeft: "150px",marginTop:'80px' }} height='520' src={loginImg} alt="" />
                    </Col>
                    <Col>
                        {hasAccount ? (
                            <Card style={{ width: "42vw", padding: "20px",marginTop:'70px' }}>
                                <br /><br />
                                <center><h4 className="">Login to your <b>{type}</b> account</h4></center>
                                <br />
                                <center><h5>Login by entering the information below</h5></center>
                                <br /><br />
                                <center>
                                    <Form onSubmit={handleLogin}>
                                        <Form.Group className="mb-3" controlId="formBasicEmailLogin">
                                            <Form.Control required style={{ width: "500px" }} type="email" placeholder="Enter email" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicPasswordLogin">
                                            <Form.Control style={{ width: "500px" }} type="password" placeholder="Password" />
                                        </Form.Group>
                                        {err !== '' &&
                                            <span style={{ color: "red" }}>{err}</span>}
                                        <br />
                                        <Button1 style={{ width: "200px" }} variant="outline-dark" type="submit">
                                            Login
                                        </Button1>
                                    </Form>
                                </center>
                                <br /><br />
                                <center>
                                    <Button1 onClick={() => setHasAccount(false)} style={{ width: "500px" }} variant="link">
                                        Don't have an Account?
                                    </Button1>
                                    <br /><br />
                                </center>
                            </Card>
                        ) : (
                            <Card style={{ width: "42vw", padding: "20px",marginTop:'70px' }}>
                                {type === 'student' ? (
                                    <>
                                        <center><h4 className="">Create a new Student Account</h4></center>
                                        <center><h5>Sign in by entering the information below</h5></center>
                                        <br />
                                        <center><Form onSubmit={handleSignup}>
                                            <div style={{ display: 'flex' }}>
                                                <Form.Group className="mb-3" controlId="formBasicNameStudent">
                                                    <Form.Control required style={{ width: "300px" }} type="text" placeholder="Enter Full Name" />
                                                </Form.Group>
                                                <Form.Group className="mb-3" controlId="formBasicAgeStudent">
                                                    <Form.Control required style={{ width: "150px", marginLeft: '50px' }} type="number" placeholder="Enter Age" />
                                                </Form.Group>
                                            </div>
                                            <Form.Group className="mb-3" controlId="formBasicMobNoStudent">
                                                <Form.Control required style={{ width: "500px" }} type="number" placeholder="Enter Mobile Number" />
                                            </Form.Group>
                                            <Form.Group className="mb-3" controlId="formBasicEmailStudent">
                                                <Form.Control required style={{ width: "500px" }} type="email" placeholder="Enter email" />
                                            </Form.Group>

                                            <Form.Group className="mb-3" controlId="formBasicPasswordStudent">
                                                <Form.Control required style={{ width: "500px" }} type="password" placeholder="Enter Password" />
                                            </Form.Group>
                                            <Form.Group className="mb-3" controlId="formBasicConfirmPasswordStudent">
                                                <Form.Control required style={{ width: "500px" }} type="password" placeholder="Confirm Password" />
                                            </Form.Group>
                                            {err !== '' &&
                                                <span style={{ color: "red" }}>{err}</span>}
                                            <br />


                                            <Button1 style={{ width: "200px" }} variant="outline-dark" type="submit">
                                                Sign Up
                                            </Button1>
                                        </Form></center>
                                        <center><Button1 onClick={() => setHasAccount(true)} style={{ width: "500px" }} variant="link" type="submit">
                                            Already have an Account?
                                        </Button1></center>
                                    </>
                                ) : (type === 'mentor' ? renderMentorForm() : renderAdminForm())}
                            </Card>
                        )}
                    </Col>
                </Row>
            </div>
            <div className="toast-bottom">
                <Toast ref={toast} position="bottom-right" />
            </div>
        </>
    );
};

const styles = {
    sidebar: {
        width: '22vh',
        height: '115vh',
        position: 'fixed',
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        boxShadow: '2px 0 4px rgba(0, 0, 0, 0.5)',
        padding: '10px 0',
        marginTop: '-80px',
        zIndex: '1'
    },
    sidebarButton: {
        fontSize: '1.5rem',
        marginBottom: '10px', // Add spacing between buttons
    },
};

export default Login;
