// Navbar.jsx
import React, { useEffect, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import Button1 from 'react-bootstrap/Button';
import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import home1 from '../images/home1.png';
import home2 from '../images/home2.jpg'
import CourseService from '../services/CourseService';
import course1 from '../images/course1.jpg';
import course2 from '../images/course2.jpg';
import course3 from '../images/course3.avif';
import course4 from '../images/course4.avif';
import { Card, Form, Modal, Table } from 'react-bootstrap';
import { Toast } from 'primereact/toast';
import StudentService from '../services/StudentService';
import certificateTemplate from '../images/certificateTemplate.jpg';
import * as htmlToImage from 'html-to-image';
import download from 'downloadjs';
import LoginService from '../services/LoginService';

const StudentDashboard = () => {

    const certificateRef = useRef(null); // Ref to capture the certificate element

    const toast = useRef(null);
    const [tab, setTab] = useState('course');
    const [courseData, setCourseData] = useState([]);
    const [courseModalShow, setCourseModalShow] = useState(false);
    const [isCourseUpdated, setIsCourseUpdated] = useState(false);
    const [selectedCourse, setSelectedCourse] = useState();
    const [selectedCourseImg, setSelectedCourseImg] = useState('');
    const [selectedCourseAvailableMentors, setselectedCourseAvailableMentors] = useState([]);
    const [selectedMentor, setSlectedMentor] = useState();
    const [enrolledCourseIds, setEnrolledCourseIds] = useState([]);
    const [isNewCourseEnrolled, setIsCourseEnrolled] = useState(false);

    const [myCertificate, setMyCertificate] = useState([]);
    const [myProfile, setMyProfile] = useState();
    const [isProfileUpdated, setIsProfileUpdated] = useState(false);

    const [myCourses, setMyCourse] = useState([]);
    const [courseDataCopy, setcourseDataCopy] = useState([]);
    const [globalSearch, setGlobalSearch] = useState(localStorage.getItem('globalSearchCourse'))

    useEffect(() => {
        const interval = setInterval(() => {
            const newValue = localStorage.getItem('globalSearchCourse');
            if (newValue !== globalSearch) {
                setGlobalSearch(newValue);
                // Add your logic here that you want to trigger on localStorage change
                console.log('localStorage value changed:', newValue);
            }
        }, 1000); // Poll every second

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, [globalSearch]);

    useEffect(() => {

    }, [myCourses, selectedCourseAvailableMentors, selectedCourse, selectedMentor, isNewCourseEnrolled, isProfileUpdated])
    useEffect(() => {
        const getData = async () => {
            const response = await CourseService().getAllCourse();
            if (localStorage.getItem('globalSearchCourse') !== null) {

                console.log('test useEffect', localStorage.getItem('globalSearchCourse'))
                setcourseDataCopy(response.data);
                const filteredCourses = response.data.filter(course =>
                    course.title.toLowerCase().includes(localStorage.getItem('globalSearchCourse').toLowerCase())
                );
                console.log("test", filteredCourses)
                setCourseData(filteredCourses);

            }
            else {
                console.log(response.data);
                setCourseData(response.data);
            }
        };

        const getMyCourse = async () => {
            const response = await StudentService().getMyCourse(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setMyCourse(response.data);
            console.log("Test my course", response.data);
            const enrolledIds = response.data.map(course => course.course.id);
            setEnrolledCourseIds(enrolledIds);
        };

        const getMyCertificates = async () => {
            const response = await StudentService().getMyCertificates(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setMyCertificate(response.data);
            console.log("Test my certificate", response.data);
        };

        const getMyProfile = async () => {
            const response = await LoginService().viewProfile(localStorage.getItem('jwtToken'));
            console.log(response.data);
            setMyProfile(response.data);
        };

        getData();
        getMyCourse();
        getMyCertificates();
        getMyProfile();
    }, [isCourseUpdated, globalSearch]);

    const showSccessToast = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Successfully Enrolled to Course`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const showSccessToast4 = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `SuccessFully Updated Profile`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };

    const isDateInRange = (startDateStr, endDateStr) => {
        if (startDateStr && endDateStr) {
            // Parse the date strings in the format YYYY-MM-DD
            const parseDate = (dateStr) => new Date(dateStr);

            const startDate = parseDate(startDateStr);
            const endDate = parseDate(endDateStr);
            const currentDate = new Date();

            if (currentDate >= startDate && currentDate <= endDate) {
                return "IN PROGRESS";
            } else if (currentDate < startDate) {
                return "NOT STARTED";
            } else if (currentDate > endDate) {
                return "COMPLETED";
            }
        } else {
            return "NA";
        }
    };


    const saveCertificateAsImage = async () => {
        const certificateElement = certificateRef.current;
        const dataUrl = await htmlToImage.toPng(certificateRef.current);
        download(dataUrl, 'certificate.png'); // Download image
    };

    const getRandomInt = (min, max) => {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };

    const enrollToCourse = async () => {
        const response = await StudentService().enrollToCourse(selectedCourse.id, selectedMentor.id, localStorage.getItem('jwtToken'));
        console.log(response.data);
        await showSccessToast();
        setCourseModalShow(false);
        setIsCourseEnrolled(!isNewCourseEnrolled);
    };

    const handleSelectCourse = async (course, imageSrc) => {
        const response = await CourseService().getCourseMentor(course.id, localStorage.getItem('jwtToken'));
        console.log(response.data);
        console.log(course)
        setselectedCourseAvailableMentors(response.data);
        setSelectedCourse(course)
        setSelectedCourseImg(imageSrc)
        setCourseModalShow(true)
    };

    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        let body = {
            "fullName": e.target.formBasicNameStudentUpdate.value,
            "age": e.target.formBasicAgeStudentUpdate.value,
            "mobNo": e.target.formBasicMobNoStudentUpdate.value
        }
        const response = await StudentService().updateProfile(localStorage.getItem('jwtToken'), body);
        console.log(response.data);
        await showSccessToast4();
        setIsProfileUpdated(!isProfileUpdated);

    };


    const imageMap = {
        1: course1,
        2: course2,
        3: course3,
        4: course4
    };

    return (
        <>
            <div>
                <div style={styles.sidebar}>
                    <Button
                        onClick={() => setTab('account')}
                        icon="pi pi-user"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                    <Button
                        onClick={() => setTab('course')}
                        icon="pi pi-objects-column"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                    <Button
                        onClick={() => setTab('certificate')}
                        icon="pi pi-crown"
                        className="p-button-text"
                        style={{ ...styles.sidebarButton, fontSize: '20px' }}
                    >
                    </Button>
                    <br />
                </div>
            </div>
            <div style={{ marginTop: '100px' }}>
                {tab === "course" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>

                        <Modal scrollable size="lg" style={{ display: 'block' }} show={courseModalShow} onHide={() => setCourseModalShow(false)}>
                            <Modal.Header closeButton>
                                <Modal.Title>Course Details</Modal.Title>
                            </Modal.Header>
                            <center>
                                {selectedCourse?.id &&

                                    <Card
                                        key={selectedCourse.id}
                                        style={{
                                            position: 'relative',
                                            width: '780px',
                                            height: '450px',
                                            backgroundSize: 'cover',
                                            backgroundPosition: 'center',
                                            color: 'white',
                                            margin: '10px',
                                            backgroundImage: `url(${selectedCourseImg})`,

                                        }}
                                    >
                                        <center><div style={styles.cardContent}>
                                            <h4>{selectedCourse.title}</h4>
                                            <br />
                                            <h5>{selectedCourse.description}</h5>
                                            <h4>Duration: {selectedCourse.duration} days</h4>
                                            {selectedCourseAvailableMentors.length ?
                                                <div style={{ margin: '20px' }}>
                                                    {!enrolledCourseIds.includes(selectedCourse.id) ?
                                                        <h3>Available Mentors</h3>
                                                        :
                                                        <h3>Your Mentor</h3>
                                                    }
                                                    <Table striped bordered hover responsive style={styles.table}>
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Experience</th>
                                                                <th>Skills</th>
                                                                <th>Mobile Number</th>
                                                                <th>Slot Details</th>
                                                                {!enrolledCourseIds.includes(selectedCourse.id) &&
                                                                    <th>Slot Available</th>}
                                                                {!enrolledCourseIds.includes(selectedCourse.id) &&
                                                                    <th>Action</th>}
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {selectedCourseAvailableMentors.length > 0 ? (
                                                                selectedCourseAvailableMentors.map((mentor, index) => (
                                                                    <tr key={index}>
                                                                        <td>{mentor.fullName}</td>
                                                                        <td>{mentor.experience} years</td>
                                                                        <td>{mentor.skills.join(', ')}</td>
                                                                        <td>{mentor.mobNo}</td>
                                                                        <td><b>{mentor.availibility.startDate}</b> - <b>{mentor.availibility.endDate}</b></td>
                                                                        {!enrolledCourseIds.includes(selectedCourse.id) &&
                                                                            <td><b>{mentor.availibility?.status}</b></td>}
                                                                        {!enrolledCourseIds.includes(selectedCourse.id) &&
                                                                            <>
                                                                                {
                                                                                    mentor.availibility?.status === 'AVAILABLE' ?
                                                                                        <>
                                                                                            {selectedMentor?.id === mentor.id ?
                                                                                                <td><Button disabled style={{ borderRadius: '5px' }} severity="success" icon='pi pi-check-circle' /></td>
                                                                                                :
                                                                                                <td><Button onClick={() => setSlectedMentor(mentor)} style={{ borderRadius: '5px' }} severity="info" icon='pi pi-check-circle' /></td>
                                                                                            }
                                                                                        </>
                                                                                        :
                                                                                        <td><Button disabled style={{ borderRadius: '5px' }} severity="danger" icon='pi pi-check-circle' /></td>
                                                                                }</>}
                                                                    </tr>
                                                                ))
                                                            ) : (
                                                                <tr>
                                                                    <td colSpan="5" style={styles.noMentors}>No mentors available</td>
                                                                </tr>
                                                            )}
                                                        </tbody>
                                                    </Table>
                                                    {enrolledCourseIds.includes(selectedCourse.id) &&
                                                        <h5>Status: {isDateInRange(myCourses[0].mentor?.availibility?.startDate, myCourses[0].mentor?.availibility?.endDate)}</h5>}
                                                    {selectedMentor &&
                                                        <Button1 onClick={enrollToCourse} variant='dark'>Enroll to Course</Button1>
                                                    }
                                                </div>
                                                :
                                                <h4>No Mentors has been assigned Yet !</h4>
                                            }
                                        </div>
                                        </center>
                                    </Card>
                                }
                            </center>
                        </Modal>
                        <div style={{ backgroundColor: '#F5EFB0', width: '100%', marginLeft: '-20px' }}>
                            <center><h5>All Courses</h5></center>
                        </div>
                        <div style={styles.cardContainer}>

                            {courseData.map((data) => {
                                let imageNumber = getRandomInt(1, 4);
                                let imageSrc = imageMap[imageNumber];
                                const isEnrolled = enrolledCourseIds.includes(data.id);
                                return (
                                    <Card
                                        onClick={() => handleSelectCourse(data, imageSrc)}
                                        key={data.id}
                                        style={{
                                            position: 'relative',
                                            width: '500px',
                                            height: '300px',
                                            backgroundSize: 'cover',
                                            backgroundPosition: 'center',
                                            color: 'white',
                                            margin: '10px',
                                            backgroundImage: `url(${imageSrc})`,
                                        }}
                                    >
                                        <center><div style={styles.cardContent}>
                                            <h4>{data.title}</h4>
                                            <br />
                                            <h5>{data.description}</h5>
                                            <h4>Duration: {data.duration} days</h4>
                                            {isEnrolled &&
                                                <Button1 disabled variant='dark' >Already Enrolled</Button1>
                                            }

                                        </div>
                                        </center>
                                    </Card>
                                );
                            })}
                        </div>

                    </div >
                }
                {tab === "certificate" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>
                        <div style={{ backgroundColor: '#F5EFB0', width: '100%', marginLeft: '-20px' }}>
                            <center><h5>Your Reports</h5></center>
                        </div>
                        <div style={styles.cardContainer}>
                            {myCertificate.length > 0 ?
                                <>
                                    {myCertificate.map((data) => {
                                        const foundCourse = myCourses.find(courseData => courseData?.course?.id === data?.courseId);

                                        console.log(" Test Course found" + myCourses, data)
                                        return (
                                            <>
                                                <Card
                                                    onClick={() => saveCertificateAsImage()}
                                                    ref={certificateRef}
                                                    key={data.id}
                                                    style={{
                                                        position: 'relative',
                                                        width: '500px',
                                                        height: '300px',
                                                        backgroundSize: 'cover',
                                                        backgroundPosition: 'center',
                                                        color: 'white',
                                                        margin: '10px',
                                                        backgroundImage: `url(${certificateTemplate})`,
                                                    }}
                                                >

                                                    <center><div style={styles.cardContentCertificate}>
                                                        <h4 style={{ marginTop: '12px', fontFamily: "cursive", }}>{foundCourse?.student?.fullName}</h4>
                                                        <div style={{ width: '400px', fontSize: '10px', lineHeightStep: '2px', marginTop: '-10px' }}>
                                                            <span style={{ fontFamily: "sans-serif" }} >in recognition of successfully completing the <b>{foundCourse?.course?.title}</b> under the mentorship of <b>{foundCourse?.mentor?.fullName}</b> on <b>{data?.generationDate}</b>.</span>
                                                        </div>
                                                    </div>
                                                    </center>
                                                </Card>
                                            </>
                                        )
                                    })}
                                </>
                                :
                                <>
                                    <h4>You have not completed any course yet !</h4>
                                    <h4>Please complete a course to get report</h4>
                                </>
                            }
                        </div>

                    </div>
                }
                {tab === "account" &&
                    <div style={{ marginTop: "20px", marginLeft: '100px' }}>
                        <center>
                            <div style={{ backgroundColor: '#F5EFB0', width: '100%', marginLeft: '-20px' }}>
                                <center><h5>Your profile</h5></center>
                            </div>
                            <br />
                            <Card style={{ width: '700px', padding: '30px', boxShadow: '0 8px 16px rgba(0, 0, 0, 0.3)' }}>
                                <center><Form onSubmit={(e) => handleProfileUpdate(e)}>
                                    <div style={{ display: 'flex' }}>
                                        <Form.Group className="mb-3" controlId="formBasicNameStudentUpdate">
                                            <Form.Control required defaultValue={myProfile.fullName} style={{ width: "400px" }} type="text" placeholder="Enter Full Name" />
                                        </Form.Group>
                                        <Form.Group className="mb-3" controlId="formBasicAgeStudentUpdate">
                                            <Form.Control required defaultValue={myProfile.age} style={{ width: "200px", marginLeft: '50px' }} type="number" placeholder="Enter Age" />
                                        </Form.Group>
                                    </div>
                                    <Form.Group className="mb-3" controlId="formBasicMobNoStudentUpdate">
                                        <Form.Control required defaultValue={myProfile.mobNo} style={{ width: "650px" }} type="number" placeholder="Enter Mobile Number" />
                                    </Form.Group>



                                    <Button type='submit' icon='pi pi-pen-to-square' severity="secondary" outlined style={{ borderRadius: '5px' }}>&nbsp;Update Profile</Button>

                                </Form></center>
                            </Card>
                        </center>
                    </div>
                }
                <div className="toast-bottom">
                    <Toast ref={toast} position="bottom-right" />
                </div>
            </div>
        </>
    );
};

const styles = {
    sidebar: {
        width: '50px',
        height: '115vh',
        position: 'fixed',
        display: 'flex',
        justifyContent: 'center',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        boxShadow: '2px 0 4px rgba(0, 0, 0, 0.5)',
        padding: '10px 0',
        marginTop: '-100px',
        zIndex: '1'
    },
    sidebarButton: {
        fontSize: '1.5rem',
        marginBottom: '10px', // Add spacing between buttons
    },
    cardContainer: {
        display: 'flex',
        flexWrap: 'wrap', // Allows wrapping of cards
        justifyContent: 'center',
        marginTop: '20px',
    },
    card: {
        position: 'relative',
        width: '500px',
        height: '300px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: 'white',
        margin: '10px',
        backgroundImage: `url(${course1})`, // You can dynamically set this in the map method
    },
    cardContent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '10px',
        background: 'rgba(0,0,0,0.4)'
    },
    cardContentCertificate: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '10px',
        color: 'black',
    },
    table: {
        marginTop: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',  // Add some shadow for effect
        borderRadius: '8px',                        // Rounded corners
        overflow: 'hidden',
        width: '775px',
        opacity: '0.8'
    },
    noMentors: {
        textAlign: 'center',
        padding: '10px',
        backgroundColor: '#f8f9fa',
    }
};

export default StudentDashboard;
