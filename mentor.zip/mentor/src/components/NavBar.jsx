// Navbar.jsx
import React, { useEffect, useRef } from 'react';
import { Button } from 'primereact/button';
import 'primeicons/primeicons.css'; // Import primeicons CSS
import 'primereact/resources/themes/saga-blue/theme.css'; // Import a theme (change if needed)
import logo from '../images/logo.png';
import home1 from '../images/home1.png';
import { useNavigate } from 'react-router-dom';
import { Form } from 'react-bootstrap';
import { Toast } from 'primereact/toast';

const Navbar = () => {
    const toast = useRef(null);
    const navigate = useNavigate();
    //For Testing
    // const FIVE_MINUTES_IN_MS = 30 * 1000; // 30 sec in milliseconds
    // const FIVE_HOURS_IN_MS = 2 * 60 * 1000; // 2 min in milliseconds
    // const THIRTY_MINUTES_IN_MS = 90 * 1000; // 1.5  min in milliseconds

    //Actual time
    const FIVE_MINUTES_IN_MS = 5 * 60 * 1000; // 5 minutes in milliseconds
    const FIVE_HOURS_IN_MS = 5 * 60 * 60 * 1000; // 5 hours in milliseconds
    const THIRTY_MINUTES_IN_MS = 30 * 60 * 1000; // 30 minutes in milliseconds

    useEffect(() => {
        const checkTokenExpiry = async () => {

            if (localStorage.getItem('jwtToken') != null) {
                const tokenIssuedAt = localStorage.getItem('tokenIssueTime');
                if (tokenIssuedAt) {
                    const tokenIssuedAtTime = parseInt(tokenIssuedAt, 10); // Convert to integer
                    const currentTime = new Date().getTime();
                    const tokenExpiryTime = tokenIssuedAtTime + FIVE_HOURS_IN_MS;

                    console.log(tokenExpiryTime / (60 * 1000) - currentTime / (60 * 1000))
                    // Check if the token is expiring within the next 30 minutes
                    if (tokenExpiryTime - currentTime <= FIVE_MINUTES_IN_MS) {
                        await showSccessToast1(tokenExpiryTime, "error");
                        localStorage.removeItem('jwtToken')
                        localStorage.removeItem('type')
                        localStorage.removeItem("tokenIssueTime", currentTime)
                    }
                    else if (tokenExpiryTime - currentTime <= THIRTY_MINUTES_IN_MS) {
                        await showSccessToast1((tokenExpiryTime - currentTime) / (60 * 1000), "warn");
                    }
                }
            }
        };

        checkTokenExpiry();
        const interval = setInterval(checkTokenExpiry, FIVE_MINUTES_IN_MS);

        // Cleanup the interval on component unmount
        return () => clearInterval(interval);
    }, []);

    const showSccessToast1 = (time, state) => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: state,
                    summary: state === 'warn'
                        ? `Your session will expire in ${time.toFixed(2)} minutes!`
                        : `Your session has expired. Please log in to continue.`,
                    life: 2000
                });
                // Resolve the promise after the toast is displayed for 2 seconds
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };
    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent the default form submission

        const courseValue = e.target.formBasicCourse.value;
        localStorage.setItem("globalSearchCourse", courseValue);
        if (localStorage.getItem('jwtToken')) {
            if (localStorage.getItem('type') === 'student')
                navigate('/dashboard/student');
            else if (localStorage.getItem('type') === 'mentor')
                navigate('/dashboard/mentor');
            else if (localStorage.getItem('type') === 'admin')
                navigate('/dashboard/admin');

        }
        else
            navigate('/search');
    };
    const showSccessToast = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "warn",
                    summary: `Please Login to Access Dashboard`,
                    life: 2000
                });
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };
    const showSccessToast2 = () => {
        return new Promise((resolve) => {
            if (toast.current) {
                toast.current.show({
                    severity: "success",
                    summary: `Logged Out Successfully`,
                    life: 2000
                });
                // Resolve the promise after the toast is displayed for 2 seconds
                setTimeout(resolve, 2000);
            } else {
                resolve();
            }
        });
    };
    return (
        <div style={{ zIndex: '200', position: 'absolute', width: '100vw', top: '0' }}>
            <nav style={styles.navbar}>
                <img height={50} src={logo} alt="Logo" style={styles.logo} />
                <Form onSubmit={handleSubmit} style={styles.logo}>
                    <Form.Group className="mb-3" controlId="formBasicCourse">
                        <Form.Control required
                            style={{ width: "500px", marginTop: '10px', borderRadius: '20px' }}
                            type="text"
                            placeholder="Search Course"
                            onChange={(e) => {
                                console.log("local", e.target.value)
                                if (e.target.value === "")
                                    localStorage.removeItem("globalSearchCourse");
                            }}
                        />
                    </Form.Group>
                    &nbsp;
                    <Button
                        type="submit"
                        text
                        icon="pi pi-search"
                        style={{ fontSize: '1.5rem' }}
                    />
                </Form>
                <div style={styles.buttonContainer}>
                    <Button onClick={async () => {
                        if (localStorage.getItem('type') === 'admin')
                            navigate("/dashboard/admin");
                        else if (localStorage.getItem('type') === 'mentor')
                            navigate("/dashboard/mentor");
                        else if (localStorage.getItem('type') === 'student')
                            navigate("/dashboard/student");
                        else
                            await showSccessToast();

                    }} icon="pi pi-clipboard" className="p-button-text" style={styles.button} />
                    <Button onClick={() => {
                        navigate("/");
                    }} icon="pi pi-home" className="p-button-text" style={styles.button} />
                    {localStorage.getItem('jwtToken') != null ?
                        <Button
                            onClick={async () => {
                                localStorage.removeItem('jwtToken')
                                localStorage.removeItem('type')
                                await showSccessToast2();
                                navigate('/');
                            }
                            }
                            icon="pi pi-sign-out"
                            className="p-button-text"
                            style={{ ...styles.sidebarButton, fontSize: '20px' }}
                        >
                        </Button>
                        :
                        <Button onClick={() => {
                            navigate("/login");
                        }} icon="pi pi-user" className="p-button-text" style={styles.button} />
                    }
                </div>

            </nav>
            <div className="toast-bottom">
                <Toast ref={toast} position="bottom-right" />
            </div>
        </div>
    );
};

const styles = {
    navbar: {
        display: 'flex',
        alignItems: 'center',
        top: 0,
        justifyContent: 'space-between', // This will align items to the left and right
        backgroundColor: '#f8f9fa',
        padding: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    logo: {
        display: 'flex',
        marginRight: 'auto', // This ensures that the logo stays on the left
    },
    buttonContainer: {
        display: 'flex',
        alignItems: 'center',
    },
    button: {
        fontSize: '1.9rem',
        marginLeft: '10px', // Add spacing between buttons
        marginRight: '20px',
        borderRadius: '10%'
    },
};

export default Navbar;
